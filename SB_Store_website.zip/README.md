# 🎮 S&B Store website

Dit is een volledig gratis, statische website voor S&B Store.

## Zo gebruik je hem
1. Open `index.html` in je browser om de website te bekijken.
2. Zoek in het bestand naar `Vervang eerst de #` en vervang de `#` van de Discord-knop door je eigen Discord invite-link.
3. Voor gratis online hosting kun je GitHub Pages gebruiken.

## Belangrijk
De website bevat alleen legitieme Discord/serverbouw-diensten. Er staan geen aanbiedingen voor externe Fortnite-accounts of niet-officiële V-Bucks-verkoop op.
